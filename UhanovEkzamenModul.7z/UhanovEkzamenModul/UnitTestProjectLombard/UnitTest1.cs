﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using UhanovEkzamenModul;

namespace UnitTestProjectLombard
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
                bool expect = true;
                bool Result = MainWindow.Validation("uhanov", "uhanov");
                Assert.AreEqual(expect, Result);
            }

            [TestMethod]
            public void TestAuth()
            {
                string Login = "uhanov";
                string Password = "uhanov";
                bool expect = true;
                bool result = MainWindow.TestAuth(Password, Login);
                Assert.AreEqual(expect, result);
            }
        }
    }

