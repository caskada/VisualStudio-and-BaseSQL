﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UhanovEkzamenModul
{
    class ClassConnect
    {
        public static LombardExamEntities bd;

        public static LombardExamEntities GetContext()
        {
            if (bd == null)
            {
                bd = new LombardExamEntities();
            }
            return bd;
        }
    }
}
    

