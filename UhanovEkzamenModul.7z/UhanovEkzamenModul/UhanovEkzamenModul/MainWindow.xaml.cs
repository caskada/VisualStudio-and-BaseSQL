﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace UhanovEkzamenModul
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        public static bool TestResult = false;
        private void Login_Click(object sender, RoutedEventArgs e)
        {
            if (Login.Text == "")
            {
                MessageBox.Show("Вы не ввели логин!");
            }
            else
            {
                if (Password.Text == "")
                {
                    MessageBox.Show("Вы не ввели пароль!");
                }
                else
                {
                    if (ClassConnect.GetContext().Sotrudniki.Any(a => a.Login == Login.Text) == true)
                    {
                        var Sotrudnik = ClassConnect.GetContext().Sotrudniki.Where(a => a.Login == Login.Text).First();
                        if (Sotrudnik.Parol == Password.Text)
                        {
                            Window1 wd = new Window1();
                            wd.Show();
                            this.Visibility = Visibility.Collapsed;
                            MessageBox.Show("Авторизация прошла успешно!");
                        }
                        else
                        {
                            MessageBox.Show("Ввели неправильный логин или пароль!");
                        }
                    }
                }
            }
        }
        public static bool Validation(string Password, string Login)
        {
            bool result = false;
            if (Password == "")
            {
                result = false;
            }
            else
            {
                if (Login == "")
                {
                    result = false;
                }
                else
                {
                    result = true;
                }
            }
            return result;
        }
        public static bool TestAuth(string Password, string Login)
        {
            if (ClassConnect.GetContext().Sotrudniki.Any(a => a.Login == Login) == true)
            {
                var Sotrudnik = ClassConnect.GetContext().Sotrudniki.Where(a => a.Login == Login).First();
                if (Sotrudnik.Parol == Password)
                {
                    TestResult = true;
                }
                else
                {
                    TestResult = false;
                }
            }
            return TestResult;
        }
        private void Clear_Click(object sender, RoutedEventArgs e)
        {
            Login.Clear();
            Password.Clear();
        }
    }
}
    

